import '../src/education.css'
export default function Education() {
     return (
     <>
    <p>Education Qualification</p>
     </>
     );
     }
    